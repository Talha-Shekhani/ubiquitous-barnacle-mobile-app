import React from 'react';
import { StyleSheet, Text, View, TextInput,TouchableOpacity, Dimensions, Image,ScrollView } from 'react-native';
import HeaderAfter from '../HeaderAfterSignIn'
import IconAnt from 'react-native-vector-icons/AntDesign'; 
import { useNavigation, useTheme } from '@react-navigation/native'
import { RFValue } from 'react-native-responsive-fontsize'
import IconIon from 'react-native-vector-icons/Ionicons'; 
import IconFont from 'react-native-vector-icons/FontAwesome';
import IconMaterial from 'react-native-vector-icons/MaterialIcons';
import IconSimple from 'react-native-vector-icons/SimpleLineIcons';
const WIDTH = Dimensions.get('window').width;
const HEIGHT = Dimensions.get('window').height;


export default function Home(){
    const navigation = useNavigation();

    return(
        <View style={styles.mainView}>
            <ScrollView showsVerticalScrollIndicator={false}>
                <IconMaterial name="notifications-none" size={30} color="black" style={styles.signUp} />
                <View style={styles.row}>
                    <Image source={require('../../assets/tibLogoPng.png')}
                        style={styles.logo} />
                    <Text style={{ marginLeft: RFValue(10), }}>
                        {/* style={styles.signUp} */}
                    Member Name {"\n"} Welcome Here
                </Text>
                </View>

                <View style={[styles.row, {marginTop: 30,justifyContent: "space-around"}]}>
                <TouchableOpacity style={styles.buttonStyle} activeOpacity={.5}>
                <View style={[styles.row, {justifyContent: "space-between"}]}>
                        <IconIon name="md-person-add" color="#1b963c" size={40} />
                        <Text style={styles.TextStyle}> Upcoming {"\n"} Appoinments</Text>
                        </View>
                    </TouchableOpacity>
                    <Image source={require('../../assets/Group37.png')}
                        style={styles.logo2} />
                </View>
                <View style={styles.rowView}>
                    <View style={styles.yellow}></View>
                    <View style={styles.green}></View>
                    <View style={styles.blue}></View>
                    <View style={styles.red}></View>
                </View>
                <Text style={{fontSize: 20}}>
                    Status
                </Text>

                <View style={[styles.row, {justifyContent: "space-around"}]}>
                <TouchableOpacity style={styles.buttonStyleSmall} activeOpacity={.5}>
                        <Text style={styles.TextStyle}>Online</Text>
                    </TouchableOpacity>
                <TouchableOpacity style={styles.buttonStyleSmall} activeOpacity={.5}>
        
                    <Text style={styles.TextStyle}>Offline</Text>
                    </TouchableOpacity>
                </View>

                <TouchableOpacity style={styles.buttonStylelarge} activeOpacity={.5}
                    onPress={() => { navigation.navigate("rewiewpage") }}>
                    <Text style={styles.TextStyle2}> Profile Detail </Text>
                    <IconFont name='angle-right' size={40} />
                </TouchableOpacity>
                <TouchableOpacity style={styles.buttonStylelarge} activeOpacity={.5}
                    onPress={() => { navigation.navigate("Myaccount") }}>
                    <Text style={styles.TextStyle2}> Availability </Text>
                    <IconFont name='angle-right' size={40} />
                </TouchableOpacity>
                <TouchableOpacity style={styles.buttonStylelarge} activeOpacity={.5}
                    onPress={() => { navigation.navigate("DrCounsultant") }}>
                    <Text style={styles.TextStyle2}> Counultaion Fee </Text>
                    <IconFont name='angle-right' size={40} />
                </TouchableOpacity>
                <TouchableOpacity style={styles.buttonStylelarge} activeOpacity={.5}
                    onPress={() => { navigation.navigate("HomePayment") }}>
                    <Text style={styles.TextStyle2}> Payment Method </Text>
                    <IconFont name='angle-right' size={40} />
                </TouchableOpacity>

                <TouchableOpacity style={styles.buttonStyle} activeOpacity={.5}>
                <View style={[styles.row, {justifyContent: "space-between"}]}>
                        <IconSimple name="share-alt" color="#ff0008" size={32} />
                        <Text style={styles.TextStyle}> Previous {"\n"} Appoinments</Text>
                        </View>
                </TouchableOpacity>
            </ScrollView>
        </View>


    )
}

const styles = StyleSheet.create({

   mainView:{
    height: "100%",
    width: "100%",
    paddingHorizontal: RFValue(30),
    paddingTop: RFValue(40),
    backgroundColor: "white",
    justifyContent: "space-between"
   },
   logo: {
    height: RFValue(30),
    width: RFValue(100)
},
logo2: {
    height: RFValue(100),
    width: RFValue(100)
},
   signUp: {
    alignSelf: 'flex-end',
    },
    connect: {
        fontSize: RFValue(25),
        marginVertical: 10,
        marginBottom: 30
    },
    row: {
        flexDirection: "row",
        
    },
    rowView: {
        width: '30%',
        backgroundColor: 'white',
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: RFValue(15)
    },
    buttonStyle: {
        paddingHorizontal: 20,
        paddingVertical: 10,
        backgroundColor: 'white',
        borderRadius: 5,
        borderWidth: 2,
        borderColor: '#4789F4',
        marginVertical: 10,
        shadowColor: '#17A05D',
        shadowOpacity: 1,
        shadowOffset: {height: 2, width: 2},
        elevation: 5,
        shadowRadius: 2,
        width: "60%"
    },TextStyle:{
        textAlign: "center",
        fontSize: 16
    },
    yellow: {
        borderColor: 'yellow',
        borderBottomWidth: RFValue(5),
        width: '23%',
        marginRight: RFValue(10)
    },
    green: {
        borderColor: 'green',
        borderBottomWidth: RFValue(5),
        width: '23%',
        marginRight: RFValue(10)
    },
    blue: {
        borderColor: 'blue',
        borderBottomWidth: RFValue(5),
        width: '23%',
        marginRight: RFValue(10)
    },
    red: {
        borderColor: 'red',
        borderBottomWidth: RFValue(5),
        width: '23%',
        marginRight: RFValue(10)
    },buttonStylelarge:{
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingHorizontal: 10,
        // paddingVertical: 10,
        backgroundColor: 'white',
        borderRadius: 10,
        borderWidth: 2,
        borderColor: '#4789F4',
        marginVertical: 5,
        shadowColor: '#17A05D',
        shadowOpacity: 1,
        shadowOffset: {height: 2, width: 2},
        elevation: 5,
        shadowRadius: 2,
        marginTop: 10
    },
    TextStyle2: {
        color: 'black',
        alignSelf: 'center',
        fontSize: 18,
    },
    buttonStyleSmall: {
        paddingHorizontal: 40,
        paddingVertical: 10,
        backgroundColor: 'white',
        borderRadius: 3,
        borderWidth: 2,
        borderColor: '#4789F4',
        marginVertical: 10,
        shadowColor: '#17A05D',
        shadowOpacity: 1,
        shadowOffset: {height: 2, width: 2},
        elevation: 5,
        shadowRadius: 2,
        
    }
})