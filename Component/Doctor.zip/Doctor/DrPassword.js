import React, { useState, useRef, Component, useEffect } from 'react';
import { StyleSheet, Text, CheckBox, View, Image, TouchableOpacity, ScrollView, KeyboardAvoidingView, TextInput, Dimensions } from 'react-native';
import { useNavigation, useTheme } from '@react-navigation/native'
import IconFont from 'react-native-vector-icons/FontAwesome';
// import { Header } from 'react-navigation-stack';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import IconMaterial from 'react-native-vector-icons/MaterialCommunityIcons';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import { RFValue } from 'react-native-responsive-fontsize'
const WIDTH = Dimensions.get('window').width;
const HEIGHT = Dimensions.get('window').height;
import Header from './DrHeaderSignUp'
import Footer from '../Patient/Footer'
import { useForm } from 'react-hook-form'
import { p_signUpPage } from '../../redux/ActionCreators';
import { useDispatch, useSelector } from 'react-redux'

// const mapDispatchToProps = dispatch => ({
//     p_signin: () => dispatch(p_signin()) 
//   })

function DrPassword(props) {
    // const dispatch = useDispatch()
    // const patient = useSelector(state => state)
    const { handleSubmit, register, errors, setValue } = useForm();

    const onSubmit = values => { 
        
        var data = props.route.params.data
        var val = Object.assign(data, values)
        console.log("password")
        console.log(val)
        // dispatch(d_signUpPage(val))
        navigation.navigate('finish', {data: val})
    };

    useEffect(() => {
        register('p_password')
        // register('p_pin')
    }, [register])

    const [text, setText] = useState("")
    const [textPhone, setTextPhone] = useState("")
    const [pin1, setpin1] = useState("")
    const [pin2, setpin2] = useState("")
    const [pin3, setpin3] = useState("")
    const [pin4, setpin4] = useState("")
    const ref_input1 = useRef();
    const ref_input2 = useRef();
    const ref_input3 = useRef();
    const ref_input4 = useRef();
    const [isSelected, setSelection] = useState(false);
    const navigation = useNavigation();
    return (
        <View style={ styles.mainView }>
            <ScrollView>
                    <Header />
                    <View style={{ marginTop: 5 }} >
                        <TextInput style={styles.textInput}
                        onChangeText={(text) => setValue('p_password', text)}
                            placeholder={"Password"}
                        />
                    </View>
                    <View style={{ flexDirection: "row", margin: 10 }}>
                        <Text style={{ fontSize: 20, fontWeight: "bold", marginTop: 10 }}>Weak</Text>
                        <Text style={{ fontSize: 20, fontWeight: "bold", marginTop: 10, marginLeft: 40 }}>Strong</Text>
                    </View>
                    <View style={{ flexDirection: "row" }}>
                        <IconFont name="circle" size={20} color="#7ff5f3" style={{ margin: 4 }} />
                        <IconFont name="circle" size={20} color="#7ff5f3" style={{ margin: 4 }} />
                        <IconFont name="circle" size={20} color="#7ff5f3" style={{ margin: 4 }} />
                        <IconFont name="circle" size={20} color="#7ff5f3" style={{ margin: 4 }} />

                        <IconFont name="circle" size={20} color="#00a809" style={{ margin: 4 }} />
                        <IconFont name="circle" size={20} color="#00a809" style={{ margin: 4 }} />
                        <IconFont name="circle" size={20} color="#00a809" style={{ margin: 4 }} />
                        <IconFont name="circle" size={20} color="#00a809" style={{ margin: 4 }} />
                    </View>

                    <View style={{ flexDirection: "row", margin: 10 }}>
                        <IconFont name="circle" size={20} color="#00a809" />
                        <Text style={{ fontSize: 20, marginLeft: 8, marginTop: -4 }}>8 characters Minimum</Text>
                    </View>


                    <View style={{ flexDirection: "row", margin: 10 }}>
                        <IconFont name="circle" size={20} color="#00a809" />
                        <Text style={{ fontSize: 20, marginLeft: 8, marginTop: -4 }}>One number  </Text>
                    </View>

                    <Text style={{ fontSize: 30, fontWeight: "bold", margin: 10, marginTop: -5 }}>Security Pin  </Text>

                    <View style={{ flexDirection: "row", justifyContent: "space-evenly" }}>
                        <TextInput
                            // placeholder="Input1"
                            autoFocus={true}
                            returnKeyType="next"
                            ref={ref_input1}
                            onChangeText={(pin1) => {setpin1(pin1); {
                                if (pin1.length === 1) ref_input2.current.focus();
                            }}}
                            value={pin1}
                            maxLength={1}
                            style={{ backgroundColor: "#f5f4f2", alignContent: "center", justifyContent: "center", fontWeight: "600", fontSize: 20, height: 55, width: "10%", borderRadius: 10, borderWidth: 0.5, borderColor: "grey", textAlign: "center" }}
                        />
                        <TextInput
                            // placeholder="Input2"
                            returnKeyType="next"
                            ref={ref_input2}
                            onChangeText={(pin2) => {setpin2(pin2); {
                                if (pin2.length === 1) ref_input3.current.focus(); else if (pin2.length === 0) ref_input1.current.focus();
                            }}}
                            value={pin2}
                            maxLength={1}
                            style={{ backgroundColor: "#f5f4f2", alignContent: "center", justifyContent: "center", fontWeight: "600", fontSize: 20, height: 55, width: "10%", borderRadius: 10, borderWidth: 0.5, borderColor: "grey", textAlign: "center" }}
                        />
                        <TextInput
                            // placeholder="Input3"
                            returnKeyType="next"
                            ref={ref_input3}
                            onChangeText={(pin3) => {setpin3(pin3); {
                                if (pin3.length === 1) ref_input4.current.focus(); else if (pin3.length === 0) ref_input2.current.focus();
                            }}}
                            value={pin3}
                            maxLength={1}
                            style={{ backgroundColor: "#f5f4f2", alignContent: "center", justifyContent: "center", fontWeight: "600", fontSize: 20, height: 55, width: "10%", borderRadius: 10, borderWidth: 0.5, borderColor: "grey", textAlign: "center" }}
                        />
                        <TextInput
                            // placeholder="Input4"
                            ref={ref_input4}
                            onChangeText={(pin4) => {setpin4(pin4); {
                                if (pin4.length === 0) ref_input3.current.focus();
                            }}}
                            value={pin4}
                            maxLength={1}
                            style={{ backgroundColor: "#f5f4f2", alignContent: "center", justifyContent: "center", fontWeight: "600", fontSize: 20, height: 55, width: "10%", borderRadius: 10, borderWidth: 0.5, borderColor: "grey", textAlign: "center" }}
                        />
                    </View>
                    {/* <SmoothPinCodeInput
                    cellStyle={{
                        borderBottomWidth: 2,
                        borderColor: 'gray',
                    }}
                    cellStyleFocused={{
                        borderColor: 'black',
                    }}
                    value={this.state.code}
                    onChangeText={code => this.setState({ code })}
                /> */}

                    <View style={{ flexDirection: "row", marginTop: 20 }}>
                        <CheckBox
                            value={isSelected}
                            onValueChange={setSelection}
                            style={styles.checkbox}
                        />
                        <Text style={{ fontSize: 15, width: "80%", marginLeft: RFValue(10) }}>
                            I agree to Tibb Doctor's Terms of use informed & Constent and privacy policy </Text>
                    </View>

                    {/* < {isSelected ?  : "👎"} */}

                    <View style={{ marginTop: 30 }}></View>
                    <TouchableOpacity
                        style={styles.SubmitButtonStyle}
                        activeOpacity={.5}
                        onPress={handleSubmit(onSubmit)}

                        // onPress={() => { navigation.navigate("finish") }}
                    >
                        <Text style={styles.TextStyle}> CREATE ACCOUNT </Text>

                    </TouchableOpacity>
                    </ScrollView>
            <View>
                <IconFont name="arrow-circle-left" size={50} color="#2c97c9"
                    onPress={() => { navigation.goBack() }}
                />
                <Footer />
            </View>
            </View>
    );
}

const styles = StyleSheet.create({
    
    mainView: {
        width: "100%",
        height: "100%",
        paddingHorizontal: RFValue(20),
        paddingTop: RFValue(20),
        backgroundColor: 'white',
        justifyContent: 'space-between',
    },

    MainContainer: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor: '#F5FCFF',
    },

    SubmitButtonStyle: {

        marginTop: 10,
        paddingTop: 15,
        paddingBottom: 15,
        marginLeft: 30,
        marginRight: 30,
        backgroundColor: 'white',
        borderRadius: 10,
        borderWidth: 3,
        borderColor: 'green'
    },

    TextStyle: {
        color: 'black',
        textAlign: 'center',
        fontSize: 18,
        fontWeight: "bold"
    },
    textWrapper: {
        height: hp('90%'), // 70% of height device screen
        width: wp('90%')   // 80% of width device screen
    },
    //   myText: {
    //     fontSize: hp('5%') // End result looks like the provided UI mockup
    //   },
    textInput: {
        borderBottomColor: 'black',
        borderBottomWidth: RFValue(2),

    },
    checkbox: {
        alignSelf: "center",
    },

});

export default DrPassword