const nodemailer = require("nodemailer");
const transport = nodemailer.createTransport({
    host: 'smtp.gmail.com',
	port: 465,
	secure: true,
	auth: {
		user: 'eprotaxapp@gmail.com',
		pass: '7uW9f98d5bcgqfB'
	},
	tls: {
		// do not fail on invalid certs
		rejectUnauthorized: false
	}
});

module.exports = transport