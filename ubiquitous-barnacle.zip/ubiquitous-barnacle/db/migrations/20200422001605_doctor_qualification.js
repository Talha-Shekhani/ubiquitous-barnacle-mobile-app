
exports.up = function(knex) {
  return knex.schema.createTable('doctor_qualification',(table) => {
	  table.increments();
		table.integer('doctor_id').unsigned().references('id').inTable('doctor_profile').notNullable();
		table.integer('qualificaiton_id').unsigned().references('id').inTable('qualification').notNullable();
		table.date('qual_year').notNullable();
		table.integer('country_id').unsigned().notNullable();
		table.timestamp("created_at").defaultTo(knex.fn.now());
		table.timestamp('updated_at').defaultTo(knex.raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
	})
};

exports.down = function(knex) {
  return knex.schema.dropTableIfExists('doctor_qualification');
};
