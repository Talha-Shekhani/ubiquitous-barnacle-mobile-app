exports.up = function(knex) {
	return knex.schema.createTable('doctor_language',(table) => {
	  table.increments();
		table.integer('doctor_id').unsigned().references('id').inTable('doctor_profile').notNullable();
		table.integer('language_id').unsigned().references('id').inTable('languages').notNullable();
		table.timestamp("created_at").defaultTo(knex.fn.now());
		table.timestamp('updated_at').defaultTo(knex.raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
	})
};

exports.down = function(knex) {
  return knex.schema.dropTableIfExists('doctor_language');
};
