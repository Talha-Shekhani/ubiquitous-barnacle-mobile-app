
exports.up = function(knex) {
	return knex.schema.createTable('qualification',(table) => {
	  table.increments();
		table.string('qual_name').notNullable();
		table.string('qual_short_name').notNullable();
		table.timestamp("created_at").defaultTo(knex.fn.now());
	  table.timestamp('updated_at').defaultTo(knex.raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
	})
};

exports.down = function(knex) {
  return knex.schema.dropTableIfExists('qualification');
};
