
exports.up = function(knex) {
  return knex.schema.createTable('doctor_available_slots',(table) => {
  	table.increments();
  	table.integer('slot_id').unsigned().references('id').inTable('slots').notNullable();
  	table.integer('doctor_id').unsigned().notNullable()
  		.references('id').inTable('doctor_profile').onDelete('CASCADE');
  	table.boolean('available').notNullable().defaultTo(1); // 1 - available 0 - not available
  	table.string('day_of_week',1).nullable().defaultTo(null); // 0 sun - 6 sat
  	table.boolean('recurring').nullable().defaultTo(0); // for future scheduling
  	table.date('date').defaultTo('2020-03-01');
  	table.timestamp("created_at").defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
  })
};

exports.down = function(knex) {
  return knex.schema.dropTableIfExists('doctor_available_slots');
};
