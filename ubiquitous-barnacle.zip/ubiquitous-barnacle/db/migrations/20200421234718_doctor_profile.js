exports.up = function(knex) {
  return knex.schema.createTable('doctor_profile',(table) => {
  	table.increments();
  	table.string('d_email').unique().notNullable();
  	table.string('d_password').notNullable();
  	table.string('d_title',20).notNullable(); // title -> username??
  	table.string('d_first_name',20).notNullable();
  	table.string('d_last_name',20).notNullable();
  	table.string('d_phone_no',30).notNullable();
	table.integer('d_country_id').unsigned().notNullable();
	table.integer('p_state_id').unsigned().notNullable();
	table.integer('p_city_id').unsigned().notNullable();
  	table.date('d_dob').notNullable();
    table.integer('d_pin_code').notNullable();
  	table.string('d_gender',1).notNullable();
    table.string('about_me',250).nullable().defaultTo('');
    table.boolean('accout_locked').defaultTo(0); // 1 - locked :: 0 - not locked
  	table.timestamp("created_at").defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
  })
};

exports.down = function(knex) {
  return knex.schema.dropTableIfExists('doctor_profile');
};

