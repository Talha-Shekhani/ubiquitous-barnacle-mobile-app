
exports.up = function(knex) {
  return knex.schema.createTable('appointments',(table) => {
  	table.increments();
  	table.integer('doctor_slot_id').unsigned().notNullable().defaultTo(0);
  	table.integer('patient_id').unsigned().notNullable().defaultTo(0);
  	table.integer('doctor_id').unsigned().notNullable().defaultTo(0);
  	table.integer('patient_details_id').unsigned().nullable().defaultTo(null);
  	table.string('speciality',50).nullable().defaultTo(null); //disease - speciality whatever
  	table.timestamp("created_at").defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
  })
};

exports.down = function(knex) {
  return knex.schema.dropTableIfExists('appointments');
};
