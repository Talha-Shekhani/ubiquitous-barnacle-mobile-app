
exports.up = function(knex) {
	return knex.schema.createTable('patient_appointment_details',(table) => {
		table.increments();
		table.string('first_name',20).notNullable();
		table.string('last_name',20).notNullable();
		table.integer('patient_id').unsigned().notNullable();
		table.string('gender',10).notNullable();
		table.date('dob').notNullable();
		table.string('relation',50).nullable().defaultTo(null);
		table.integer('appointment_status').notNullable();

		table.date('appointment_date').notNullable();
	  table.timestamp("created_at").defaultTo(knex.fn.now());
	  table.timestamp('updated_at').defaultTo(knex.raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
	})
};

exports.down = function(knex) {
	return knex.schema.dropTableIfExists('patient_appointment_details');  
};
