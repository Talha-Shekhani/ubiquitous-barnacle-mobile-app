
exports.up = function(knex) {
	return knex.schema.createTable('resetTokens',(table) => {
	  table.increments();
		table.string('email').nullable().defaultTo(null);
		table.string('token').nullable().defaultTo(null);
		table.string('reset_type').nullable().defaultTo(null); // resetting password or pin 
		table.datetime('expiration').nullable().defaultTo(null);
		table.boolean('used').defaultTo(null);
		table.timestamp("created_at").defaultTo(knex.fn.now());
		table.timestamp('updated_at').defaultTo(knex.raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
	})
};

exports.down = function(knex) {
  return knex.schema.dropTableIfExists('resetTokens');
};
