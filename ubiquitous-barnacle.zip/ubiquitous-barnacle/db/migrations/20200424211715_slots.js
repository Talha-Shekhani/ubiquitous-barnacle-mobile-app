
exports.up = function (knex) {
  return knex.schema.createTable('slots',(table) => {
  	table.increments();
  	table.time('start_time').notNullable().defaultTo('00:00:00');
  	table.time('end_time').notNullable().defaultTo('00:00:00');
  	table.timestamp("created_at").defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
  })
  .then(() => {
  	return knex.schema
    .raw(`ALTER TABLE slots ADD CONSTRAINT CHK_slot 
    CHECK (start_time < end_time AND TIMEDIFF(end_time,start_time) = '00:30:00');`);
  })
}; // find a way to add constraints 

exports.down = function(knex) {
  return knex.schema.dropTableIfExists('slots')
};
