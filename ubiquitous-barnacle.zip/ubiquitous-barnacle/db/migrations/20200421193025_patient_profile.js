
exports.up = function(knex) {
  return knex.schema.createTable('patient_profile',(table) => {
  	table.increments();
  	table.string('p_email').unique().notNullable();
  	table.string('p_password').notNullable();
  	table.string('p_title',20).notNullable(); // title -> username??
  	table.string('p_first_name',20).notNullable();
  	table.string('p_last_name',20).notNullable();
  	table.integer('p_country_id').unsigned().notNullable();
  	table.integer('p_state_id').unsigned().notNullable();
  	table.integer('p_city_id').unsigned().notNullable();
  	table.string('p_phone_no',30).notNullable();
  	table.date('p_dob').notNullable();
  	table.string('p_gender',1).notNullable();
  	table.integer('p_pin_code').notNullable();
	table.boolean('accout_locked').defaultTo(0); // 1 - locked :: 0 - not locked
	table.boolean('account_status').defaultTo(0); // 1 - locked :: 0 - not locked
  	table.timestamp("created_at").defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
  })
};

exports.down = function(knex) {
  return knex.schema.dropTableIfExists('patient_profile');
};
