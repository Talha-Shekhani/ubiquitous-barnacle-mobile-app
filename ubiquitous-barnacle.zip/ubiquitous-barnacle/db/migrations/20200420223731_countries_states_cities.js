
exports.up = function(knex) {
  return knex.schema.createTable('countries',(table) => {
  	table.increments();
  	table.string('short_name',3).notNullable();
  	table.string('country_name',50).notNullable();
  	table.integer('phone_code').notNullable();
  	table.timestamp("created_at").defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
  })
  .createTable('states',(table) => {
  	table.increments();
  	table.string('state_name',50).notNullable();
  	table.integer('country_id').unsigned().references('id').inTable('countries').notNull();
  	table.timestamp("created_at").defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
  })
  .createTable('cities',(table) => {
  	table.increments();
  	table.string('city_name',50).notNullable();
  	table.integer('state_id').unsigned();
  	table.timestamp("created_at").defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
  })
};

exports.down = function(knex) {
  return knex.schema
  	.dropTableIfExists('cities')
  	.dropTableIfExists('states')
  	.dropTableIfExists('countries')
};
