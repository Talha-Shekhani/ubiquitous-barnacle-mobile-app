
exports.up = function(knex) {
  return knex.schema.createTable('languages',(table) => {
  	table.increments();
  	table.string('lang_name').unique().notNullable();
  	table.string('lang_short_name').unique().notNullable();
  	table.timestamp("created_at").defaultTo(knex.fn.now());
	  table.timestamp('updated_at').defaultTo(knex.raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
  })
};

exports.down = function(knex) {
  return knex.schema.dropTableIfExists('languages');
};
