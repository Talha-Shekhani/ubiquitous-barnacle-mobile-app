
exports.up = function(knex) {
  return knex.schema.createTable('doctor_consultation_fee',(table) => {
  	table.increments();
  	table.decimal('fee',10,2).nullable().defaultTo(0);
  	table.integer('doctor_id').unsigned().nullable().defaultTo(null);
  	table.integer('currency_id').unsigned().nullable().defaultTo(0);
  	table.boolean('locked').defaultTo(0); // 1 - locked :: 0 - not locked changable
  	table.timestamp("created_at").defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
  })
};

exports.down = function(knex) {
  return knex.schema.dropTableIfExists('doctor_consultation_fee');
};
