
exports.seed = function(knex) {
  // Deletes ALL existing entries
  return knex('qualification').del()
    .then(function () {
      // Inserts seed entries
      return knex('qualification').insert([
        {id:1,qual_name:'Bachelor of Medicine, Bachelor of Surgery',qual_short_name:'MBBS'},
        {id:2,qual_name:'Doctor of Medicine',qual_short_name:'MD'}
      ]);
    });
};
