
exports.seed = function(knex) {
  // Deletes ALL existing entries
  return knex('languages').del()
    .then(function () {
      // Inserts seed entries
      return knex('languages').insert([
        {"id":1, "lang_short_name":"en" ,"lang_name":"English"},
        {"id":2, "lang_short_name":"fr" ,"lang_name":"French"},
        {"id":3, "lang_short_name":"es" ,"lang_name":"Spanish"},
        {"id":4, "lang_short_name":"ar" ,"lang_name":"Arabic"},
        {"id":5, "lang_short_name":"cmn","lang_name": "Mandarin"},
        {"id":6, "lang_short_name":"ru" ,"lang_name":"Russian"},
        {"id":7, "lang_short_name":"pt" ,"lang_name":"Portuguese"},
        {"id":8, "lang_short_name":"de" ,"lang_name":"German"},
        {"id":9, "lang_short_name":"ja" ,"lang_name":"Japanese"},
        {"id":10, "lang_short_name":"hi" ,"lang_name":"Hindi"},
        {"id":11, "lang_short_name":"ms" ,"lang_name":"Malay"},
        {"id":12, "lang_short_name":"fa" ,"lang_name":"Persian"},
        {"id":13, "lang_short_name":"sw" ,"lang_name":"Swahili"},
        {"id":14, "lang_short_name":"ta" ,"lang_name":"Tamil"},
        {"id":15, "lang_short_name":"it" ,"lang_name":"Italian"},
        {"id":16, "lang_short_name":"nl" ,"lang_name":"Dutch"},
        {"id":17, "lang_short_name":"bn" ,"lang_name":"Bengali"},
        {"id":18, "lang_short_name":"tr" ,"lang_name":"Turkish"},
        {"id":19, "lang_short_name":"vi" ,"lang_name":"Vietnamese"},
        {"id":20, "lang_short_name":"pl" ,"lang_name":"Polish"},
        {"id":21, "lang_short_name":"jv" ,"lang_name":"Javanese"},
        {"id":22, "lang_short_name":"pa" ,"lang_name":"Punjabi"},
        {"id":23, "lang_short_name":"th" ,"lang_name":"Thai"},
        {"id":24, "lang_short_name":"ko" ,"lang_name":"Korean"},
        {"id":25, "lang_short_name":"ur" ,"lang_name":"Urdu"}
      ]);
    });
};
