const { 
     doctorsDetails  , login , doctorConsultationFee ,upComingAppointmentsDetails, doctorAvailableSlots , cancelAppointmentStatus ,updateAppointmentStatus, previousAppointmentsDetails, doctorQualification ,doctorPaymentDetails , doctorLicenseDetails , doctorSpecialityDetails , doctorHigherEducationDetails
} = require("./doctorController"); 
const router = require ("express").Router();
const {loginValidation , DoctorDetialsInsertValidation  ,docPaymentDetails , docPaymentPaypalDetails , doctorConsultationFeeValidation ,docHigherEduValidation, docLicenseDetailsValidation , doctorQualificationValidation , docSpecialityDetailsValidation } = require('./doctorValidation');
const isValidated = require('../../middleware/isValidated');


router.post("/insert/doctors/details", DoctorDetialsInsertValidation , isValidated , doctorsDetails);
router.post("/login",loginValidation, isValidated , login);
router.post("/doctorConsultationFee",doctorConsultationFeeValidation, isValidated , doctorConsultationFee);
router.post("/doctorQualification" ,doctorQualificationValidation, isValidated , doctorQualification);
router.post("/doctorLicenseDetails", docLicenseDetailsValidation , isValidated , doctorLicenseDetails );
router.post("/doctorSpecialityDetails", docSpecialityDetailsValidation , isValidated , doctorSpecialityDetails );
router.post("/doctorHigherEducationDetails", docHigherEduValidation , isValidated , doctorHigherEducationDetails );
router.post("/doctorPaymentDetails", docPaymentDetails , isValidated , doctorPaymentDetails );
router.post("/doctorPaymentPaypalDetails", docPaymentPaypalDetails , isValidated , doctorPaymentDetails );
router.post("/previousAppointmentDetails" , previousAppointmentsDetails );
router.post("/upComingAppointmentDetails" , upComingAppointmentsDetails );
router.post("/updateAppointmentStatusDetails" , updateAppointmentStatus );
router.post("/cancelAppointmentStatusDetails" , cancelAppointmentStatus );
router.post("/doctorAvailableSlotsDetails" , doctorAvailableSlots );


module.exports = router;