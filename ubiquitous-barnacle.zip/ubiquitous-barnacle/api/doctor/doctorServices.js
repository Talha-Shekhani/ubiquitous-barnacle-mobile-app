const knex = require("../../db/knex");
const bcrypt = require("bcryptjs");

module.exports = {

    login: ({ d_email , d_password  }, callBack) => {
        knex
          .from("doctor_profile")
          .select("d_email", "d_password" , "accout_locked")
          .where({ d_email })
          .then((rows) => {
            if (rows.length === 0) return callBack(null, { auth: false });
            if (bcrypt.compareSync(d_password, rows[0].d_password)) {
              if (rows[0].accout_locked === 1) return callBack(null, { auth: false, msg: 'Account not Verified' });
             
              const payload = {
                d_email,
                type: "doctor_profile",
              };
              return callBack(null, { auth: true, payload });
            }
            return callBack(null, { auth: false });
          })
          .catch((err) => {
            return callBack(err);
          });
      },

    doctorsDetails: ({ d_email , d_password , d_title , d_first_name , d_last_name , d_country_id , d_state_id , d_city_id , d_phone_no , d_dob , d_gender , d_pin_code }, callBack) => {
        knex("doctor_profile")
        .insert([
            { d_email : d_email  ,
             d_password : d_password ,
             d_title : d_title ,
             d_first_name : d_first_name ,
             d_last_name : d_last_name ,
             d_country_id : d_country_id ,
             d_phone_no : d_phone_no ,
             d_dob : d_dob ,
             d_gender : d_gender  ,
             d_pin_code : d_pin_code,
             d_city_id : d_city_id ,
             d_state_id : d_state_id
            }
          ])
          .then((rows) => { callBack(null,rows)})
      .catch((err) => { callBack(err) });
      ;

    },
    doctorConsultationFee: ({ fee , doctor_id , currency_id , locked }, callBack) => {
      knex("doctor_consultation_fee")
      .insert([
          { fee : fee ,
            doctor_id : doctor_id ,
            currency_id : currency_id ,
            locked : locked
          }
        ])
        .then((rows) => { callBack(null,rows)})
    .catch((err) => { callBack(err) });
    ;

  },
  doctorQualification: ({ doctor_id , qualificaiton_id , qual_year , country_id }, callBack) => {
    knex("doctor_qualification")
    .insert([
        { doctor_id : doctor_id ,
          qualificaiton_id : qualificaiton_id ,
          qual_year : qual_year ,
          country_id : country_id
        }
      ])
      .then((rows) => { callBack(null,rows)})
  .catch((err) => { callBack(err) });
  ;

},

doctorLicenseDetails: ({ country_id , license_name , license_number , doctor_id , license_expiry_date }, callBack) => {
  knex("doctor_license_details")
  .insert([
      {
        country_id :  country_id,
        license_name : license_name,
        license_number : license_number,
        doctor_id : doctor_id,
        license_expiry_date : license_expiry_date

      }
    ])
    .then((rows) => { callBack(null,rows)})
.catch((err) => { callBack(err) });
;

},

doctorSpecialityDetails: ({ primary_speciality_id , sub_speciality_id , doctor_id }, callBack) => {
  knex("doctor_speciality")
  .insert([
      {
        primary_speciality_id :  primary_speciality_id,
        sub_speciality_id : sub_speciality_id ,
        doctor_id : doctor_id

      }
    ])
    .then((rows) => { callBack(null,rows)})
.catch((err) => { callBack(err) });
;

},
doctorHigherEducationDetails: ({ higher_degree_id , doctor_id }, callBack) => {
  knex("doctor_higher_education")
  .insert([
      {
        higher_degree_id : higher_degree_id ,
        doctor_id : doctor_id

      }
    ])
    .then((rows) => { callBack(null,rows)})
.catch((err) => { callBack(err) });
;

},

doctorPaymentDetails: ({ payment_type_id ,email_paypal, account_name , account_number , iban , bank_number , doctor_id}, callBack) => {
  knex("doctor_payment_method")
  .insert([
      {
        payment_type_id : payment_type_id ,
        account_name : account_name,
        account_number : account_number,
        iban : iban,
        bank_number : bank_number,
        doctor_id : doctor_id,
        email_paypal : email_paypal
      }
    ])
    .then((rows) => { callBack(null,rows)})
.catch((err) => { callBack(err) });
;

},

previousAppointmentsDetails: (doctor_id, callBack) => {
  const results = {};
  const day = new Date().getDate();
  const month = new Date().getMonth() + 1;
  const year = new Date().getFullYear();
  const completeDate = `${year}-${month}-${day}`
  knex
    .from("appointments")
    .select("doctor_slot_id" , "patient_id" , "p_email" , "patient_details_id" , "speciality" , "appointment_date")
    .join('patient_profile', 'appointments.patient_id', '=', 'patient_profile.id')
    .whereRaw(`appointment_date <= '${completeDate}' AND doctor_id = '${doctor_id}'`)
    .orderBy('appointment_date', 'desc')
    .then((rows) => {
      results["results"] = rows;
      callBack(null, results);
      console.log(completeDate , doctor_id);

    })
    
    .catch((err) => callBack(err));
},

upComingAppointmentsDetails: (doctor_id, callBack) => {
  const results = {};
  const day = new Date().getDate();
  const month = new Date().getMonth() + 1;
  const year = new Date().getFullYear();
  const completeDate = `${year}-${month}-${day}`
  knex
    .from("appointments")
    .select("doctor_slot_id" , "patient_id" , "p_email" , "patient_details_id" , "speciality" , "appointment_date")
    .join('patient_profile', 'appointments.patient_id', '=', 'patient_profile.id')
    .whereRaw(`appointment_date > '${completeDate}' AND doctor_id = '${doctor_id}'`)
    .orderBy('appointment_date', 'desc')
    .then((rows) => {
      results["results"] = rows;
      callBack(null, results);
      console.log(completeDate , doctor_id);

    })
    
    .catch((err) => callBack(err));
},

updateAppointmentStatus: ({ patient_id, appointment_status ,doctor_slot_id , appointment_date }, callBack) => {
  knex("appointments")
    .where({ patient_id: patient_id })
    .update({ appointment_status : appointment_status , doctor_slot_id : doctor_slot_id , appointment_date : appointment_date})
    .then((rows) => { callBack(null,rows)})
    .catch((err) => { callBack(err) });
    ;

},

cancelAppointmentStatus: ({ patient_id, appointment_status }, callBack) => {
  knex("appointments")
    .where({ patient_id: patient_id })
    .update({ appointment_status : appointment_status })
    .then((rows) => { callBack(null,rows)})
    .catch((err) => { callBack(err) });
    ;

},

doctorAvailableSlots : ({doctor_id, slots},callBack) => {
  console.log(doctor_id,slots);
  const formattedData = [];
  for(let item in slots){
    console.log(item);
    slots[item].forEach(element => {
      formattedData.push({
        slot_id: element,
        date: item,
        doctor_id,
        available : true
      })
    });
  }
  console.log(formattedData);
  knex("doctor_available_slots")
  .insert(formattedData)
    .then((rows) => { callBack(null,formattedData.length)
    })
.catch((err) => { callBack(err) });
;

},

};