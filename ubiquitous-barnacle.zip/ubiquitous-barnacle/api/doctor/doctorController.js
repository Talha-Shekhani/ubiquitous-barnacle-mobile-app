const { doctorsDetails   , login , doctorConsultationFee , doctorQualification , doctorAvailableSlots ,  updateAppointmentStatus, cancelAppointmentStatus ,upComingAppointmentsDetails, doctorHigherEducationDetails , doctorLicenseDetails , doctorSpecialityDetails , doctorPaymentDetails , previousAppointmentsDetails
} = require("./doctorServices");
const JWT = require("jsonwebtoken");


module.exports = {

  login: (req, res) => {
    const d_email = req.body.d_email;
    const d_password = req.body.d_password;

    login({ d_email, d_password }, (err, results) => {
      if (err) {
        console.log(err);
        return res.json({
          err,
        });
      }
      if (!results.auth) {
        return res.json({
          success: 0,
          message: results.msg || "Username or Password Incorrect!",
        });
      }
      const token = JWT.sign(results.payload, "SECRET");
      res.cookie("access_token", token, {
        maxAge: 1000 * 60 * 60 * 24 * 365, // Unlimited Time
        httpOnly: true,
      });
      return res.json({
        ...results.payload,
        success: true,
      });
    });
  },
  doctorsDetails : (req , res) => {
    doctorsDetails( req.body , (err , results) => {
       if(err) {
         console.log(err);
         return res.status(400).send(err);
       };
       console.log(results);
   
       return res.status(200).send(results + ' Record(s) Inserted');
   
     })
   },
   doctorConsultationFee : (req , res) => {
    doctorConsultationFee( req.body , (err , results) => {
       if(err) {
         console.log(err);
         return res.status(400).send(err);
       };
       console.log(results);
   
       return res.status(200).send(results + ' Record(s) Inserted');
   
     })
   },
   doctorQualification : (req , res) => {
    doctorQualification( req.body , (err , results) => {
       if(err) {
         console.log(err);
         return res.status(400).send(err);
       };
       console.log(results);
   
       return res.status(200).send(results + ' Record(s) Inserted');
   
     })
   },

   doctorLicenseDetails : (req , res) => {
    doctorLicenseDetails( req.body , (err , results) => {
       if(err) {
         console.log(err);
         return res.status(400).send(err);
       };
       console.log(results);
   
       return res.status(200).send(results + ' Record(s) Inserted');
   
     })
   },

   doctorSpecialityDetails : (req , res) => {
    doctorSpecialityDetails( req.body , (err , results) => {
       if(err) {
         console.log(err);
         return res.status(400).send(err);
       };
       console.log(results);
   
       return res.status(200).send(results + ' Record(s) Inserted');
   
     })
   },
   doctorHigherEducationDetails : (req , res) => {
    doctorHigherEducationDetails( req.body , (err , results) => {
       if(err) {
         console.log(err);
         return res.status(400).send(err);
       };
       console.log(results);
   
       return res.status(200).send(results + ' Record(s) Inserted');
   
     })
   },
   
   doctorPaymentDetails : (req , res) => {
    doctorPaymentDetails( req.body , (err , results) => {
       if(err) {
         console.log(err);
         return res.status(400).send(err);
       };
       console.log(results);
   
       return res.status(200).send(results + ' Record(s) Inserted');
   
     })
   },

   previousAppointmentsDetails:(req,res)=>{
    try{
      const doctor_id = req.body.doctor_id
      previousAppointmentsDetails(doctor_id,(err,results)=>{
        if(err){
          console.log(err);
          return res.status(400).send({
            success:false,
            message: err.message,
            error:err
          })
        }
        console.log(results)
        return res.status(200).send({
          success: true,
          results
          })
      })
    }
    catch(error){
     res.status(500).send({
       success:false,
       message:'internal srerver',
       error:error
  })
 }
},

upComingAppointmentsDetails:(req,res)=>{
  try{
    const doctor_id = req.body.doctor_id
    upComingAppointmentsDetails(doctor_id,(err,results)=>{
      if(err){
        console.log(err);
        return res.status(400).send({
          success:false,
          message: err.message,
          error:err
        })
      }
      console.log(results)
      return res.status(200).send({
        success: true,
        results
        })
    })
  }
  catch(error){
   res.status(500).send({
     success:false,
     message:'internal srerver',
     error:error
})
}
},

updateAppointmentStatus : (req , res) => {
 
  updateAppointmentStatus(req.body, (err , results) => {
    if(err) {
      console.log(err);
      return res.status(400).send(err);
    };
    console.log(results);

    return res.status(200).send(results + ' Record(s) updated');

  })
},

cancelAppointmentStatus : (req , res) => {
 
  cancelAppointmentStatus(req.body, (err , results) => {
    if(err) {
      console.log(err);
      return res.status(400).send(err);
    };
    console.log(results);

    return res.status(200).send(results + ' Record(s) updated');

  })
},
doctorAvailableSlots: (req , res) => {
  doctorAvailableSlots( req.body , (err , results) => {
     if(err) {
       console.log(err);
       return res.status(400).send(err);
     };
     console.log(results);
 
     return res.status(200).send(results + ' Record(s) Inserted');
 
   })
 },
}