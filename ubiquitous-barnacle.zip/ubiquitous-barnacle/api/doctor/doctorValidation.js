const { body } = require('express-validator')

module.exports = {
    loginValidation :  [
        body('d_email').isEmail(),
        body('d_password').isLength({ min: 5 }),
    ],  
    DoctorDetialsInsertValidation : [
        body('d_email').isEmail().isLength({max : 254}),
        body('d_password').isLength({ min: 5 }),
        body('d_title').isAlpha().isLength({ min : 2 , max : 3 }),
        body('d_first_name').matches(/^[A-Za-z\s]+$/).isLength({max : 19}),
        body('d_last_name').matches(/^[A-Za-z\s]+$/).isLength({max : 19}),
        body('d_country_id').isNumeric().isLength({max : 9}),
        body('d_phone_no').isNumeric().isLength({max : 29}),
        body('d_dob').toDate(),
        body('d_gender').isAlpha().isLength({ max : 1 }),
        body('d_pin_code').isNumeric().isLength({max : 4}),
        body('d_state_id').isNumeric().isLength({max : 9}),
        body('d_city_id').isNumeric().isLength({max : 9}),
    ],
    doctorConsultationFeeValidation : [
        body('fee').isNumeric().isLength({max : 9}),
        body('doctor_id').isNumeric().isLength({max : 9}),
        body('currency_id').isNumeric().isLength({max : 9}),
        body('locked').isBoolean().isLength({max : 9}),
    ],
    doctorQualificationValidation : [
        body('qualificaiton_id').isNumeric().isLength({max : 9}),
        body('doctor_id').isNumeric().isLength({max : 9}),
        body('country_id').isNumeric().isLength({max : 9}),
        body('qual_year').toDate(),
    ],

    docLicenseDetailsValidation : [
       
        body('country_id').isNumeric().isLength({max : 9}),
        body('doctor_id').isNumeric().isLength({max : 9}),
        body('license_number').isAlphanumeric().isLength({max : 254}),
        body('license_name').matches(/^[A-Za-z\s]+$/).isLength({max : 254}),
        body('license_expiry_date').toDate(),
        
    ],
    docSpecialityDetailsValidation : [

        body('primary_speciality_id').isNumeric().isLength({max : 9}),
        body('sub_speciality_id').isNumeric().isLength({max : 9}),
        body('doctor_id').isNumeric().isLength({max : 9}),
    ],
    docHigherEduValidation : [
        body('higher_degree_id').isNumeric().isLength({max : 9}),
        body('doctor_id').isNumeric().isLength({max : 9}),
    ],
    docPaymentDetails : [
    
        body('payment_type_id').isNumeric().isLength({max : 9}),
        body('account_number').isAlphanumeric().isLength({max : 254}),
        body('doctor_id').isNumeric().isLength({max : 9}),
        body('iban').isAlphanumeric().isLength({max : 254}),
        body('bank_number').isAlphanumeric().isLength({max : 254}),
        body('account_name').isAlphanumeric().isLength({max : 254}),

        
    ],
    docPaymentPaypalDetails : [

        body('doctor_id').isNumeric().isLength({max : 9}),
        body('email_paypal').isEmail().isLength({max : 254}),
        body('payment_type_id').isNumeric().isLength({max : 9}),
    ]
 }