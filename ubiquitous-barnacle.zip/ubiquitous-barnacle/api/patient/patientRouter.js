const { 
        patientsDetails , login , patientsAppointment , patientsAppointmentFor,getCities,getState,getDisease,getSlots,getSubSpeciality,getDoctorId,getDoctor,getDoctorDetails,getAppointmentDetails,appointmentDetailsOfOthers,patientPaymentDetails,getPatientProfile,updatePatientProfile,accountDeactivate,updatePatientPassword,updatePatientPin,updatePatientStatus
    } = require("./patientController"); 
const {loginValidation , PatientDetialsInsertValidation} = require('./patientValidation');
const isValidated = require('../../middleware/isValidated');

const { isAuthenticated } = require('../../middleware/isAuthenticated');
const router = require ("express").Router();


router.post("/insert/patients/details", PatientDetialsInsertValidation , isValidated ,patientsDetails);
router.post("/login", loginValidation , isValidated , login);
router.post("/insert/patients/appointmnet" , patientsAppointment );
router.post("/insert/patients/appointmnetfor" , patientsAppointmentFor );
router.get("/getCities",getCities);
router.get("/getState",getState)
router.get("/getDisease",getDisease)
router.get("/getSlots",getSlots)
router.get("/getSubSpeciality",getSubSpeciality)
router.get("/getDoctorId",getDoctorId)
router.get("/getDoctor",getDoctor)
router.get("/getDoctorDetails",getDoctorDetails)
router.get("/getAppointmentDetails",getAppointmentDetails)
router.post("/appointmentDetailsOfOther" , appointmentDetailsOfOthers );
router.post("/patientPaymentDetails" , patientPaymentDetails );
router.get("/getPatientProfile",getPatientProfile)
router.post("/updatePatientProfile" , updatePatientProfile );
router.delete("/accountDeactivate" , accountDeactivate );
router.post("/updatePatientPassword" , updatePatientPassword );
router.post("/updatePatientPin" , updatePatientPin );
router.post("/updatePatientStatus" , updatePatientStatus );
module.exports = router;