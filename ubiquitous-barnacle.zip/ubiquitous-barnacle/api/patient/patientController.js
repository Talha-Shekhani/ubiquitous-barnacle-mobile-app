const { patientsDetails , login , patientsAppointment , patientsAppointmentFor ,getCities,getState,getDisease,getSlots,getSubSpeciality,getDoctorId,getDoctor,getDoctorDetails,getAppointmentDetails,appointmentDetailsOfOthers,patientPaymentDetails,getPatientProfile,updatePatientProfile,accountDeactivate,updatePatientPassword,updatePatientPin,updatePatientStatus
    } = require("./patientServices"); 
    const JWT = require("jsonwebtoken");


    module.exports = {

      login: (req, res) => {
        const p_email = req.body.p_email;
        const  p_password = req.body.p_password;
    
        login({ p_email, p_password }, (err, results) => {
          if (err) {
            console.log(err);
            return res.json({
              err,
            });
          }
          if (!results.auth) {
            return res.json({
              success: 0,
              message: results.msg || "Username or Password Incorrect!",
            });
          }
          const token = JWT.sign(results.payload, "SECRET");
          res.cookie("access_token", token, {
            maxAge: 1000 * 60 * 60 * 24 * 365, // Unlimited Time
            httpOnly: true,
          });
          return res.json({
            ...results.payload,
            success: true,
          });
        });
      },


      
    patientsDetails : (req , res) => {
   patientsDetails( req.body , (err , results) => {
      if(err) {
        console.log(err);
        return res.status(400).send(err);
      };
      console.log(results);
  
      return res.status(200).send(results + ' Record(s) Inserted');
  
    })
  },

  patientsAppointment : (req , res) => {
    patientsAppointment( req.body , (err , results) => {
       if(err) {
         console.log(err);
         return res.status(400).send(err);
       };
       console.log(results);
   
       return res.status(200).send(results + ' Record(s) Inserted');
   
     });
   },

   patientsAppointmentFor : (req , res) => {
    patientsAppointmentFor( req.body , (err , results) => {
       if(err) {
         console.log(err);
         return res.status(400).send(err);
       };
       console.log(results);
   
       return res.status(200).send(results + ' Record(s) Inserted');
   
     });
   },

   getCities:(req,res)=>{
     try{
     const state_id=req.body.state_id
     getCities(state_id,(err,results)=>{
       if(err){
         console.log(err);
         return res.status(400).send({
          success:false,
          message: err.message,
          error:error
         })
       }
       console.log(results);
       return res.status(200).send(results)
      
     })}
     catch(error){
      res.status(500).send({
        success:false,
        message:'internal srerver',
        error:error
      })
    }
    
   },
   getState:(req,res)=>{
     try{
       const country_id = req.body.country_id
       getState(country_id,(err,results)=>{
         if(err){
          console.log(err);
         return res.status(400).send({
          success:false,
          message: err.message,
          error:error
         })
         }
         console.log(results)
         return res.status(200).send(results)
       })
     }
     catch(error){
      res.status(500).send({
        success:false,
        message:'internal srerver',
        error:error
   })
  }
  
},
getDisease:(req,res)=>{
  try{
  getDisease((err,results)=>{
    
    if(err){
      console.log(err);
     return res.status(400).send({
      success:false,
      message: err.message,
      error:error
     })
     }
     console.log(results)
     return res.status(200).send(results)
  })
}
catch(error){
  res.status(500).send({
    success:false,
    message:'internal srerver',
    error:error
})

}
},

getSlots:(req,res)=>{
  try{
    getSlots((err,results)=>{
      if(err){
        console.log(err);
        return res.status(400).send({
         success:false,
         message: err.message,
         error:error
      })
    }
    console.log(results)
     return res.status(200).send(results)
   
    
    })
  }
  catch(error){
    res.status(500).send({
      success:false,
      message:'internal srerver',
      error:error
})
  }
},
getSubSpeciality:(req,res)=>{
  try{
    getSubSpeciality((err,results)=>{
      if(err){
        console.log(err);
        return res.status(400).send({
         success:false,
         message: err.message,
         error:error
        })
      }
      console.log(results)
      return res.status(200).send(results)
    })
  }
  catch(error){
    res.status(500).send({
      success:false,
      message:'internal srerver',
      error:error})
  }
},

getDoctorId:(req,res)=>{
  try{
    getDoctorId(req.body.sub_speciality_id,(err,results)=>{
      if(err){
        console.log(err);
        return res.status(400).send({
         success:false,
         message: err.message,
         error:error
        }) 
      }
      console.log(results)
      return res.status(200).send(results)
    })
  }
  catch(error){
    res.status(500).send({
      success:false,
      message:'internal srerver',
      error:error})
  }
  
},
getDoctor:(req,res)=>{
  try{
  getDoctor((err,results)=>{
    if(err){
      console.log(err);
      return res.status(400).send({
       success:false,
       message: err.message,
       error:error
      }) 
    }
    console.log(results)
    return res.status(200).send(results)
  })
}
catch(error){
  res.status(500).send({
    success:false,
    message:'internal srerver',
    error:error})
}

},
getDoctorDetails:(req,res)=>{
  try{
  getDoctorDetails(req.body.id,(err,results)=>{
    if(err){
      console.log(err);
      return res.status(400).send({
       success:false,
       message: err.message,
       error:error
      }) 
    }
    console.log(results)
    return res.status(200).send(results)
  })
   }
  catch(error){
    res.status(500).send({
      success:false,
      message:'internal srerver',
      error:error})
  }
   
},
getAppointmentDetails:(req,res)=>{
  try{
    getAppointmentDetails(req.body.patient_id,(err,results)=>{
      if(err){
        console.log(err);
        return res.status(400).send({
         success:false,
         message: err.message,
         error:error
        }) 
      }
      console.log(results)
      return res.status(200).send(results)
    })
     }
    catch(error){
      console.log(error)
      res.status(500).send({
        success:false,
        message:'internal srerver',
        error:error})
    }
  
  },
  appointmentDetailsOfOthers:(req,res)=>{
    try{
      appointmentDetailsOfOthers(req.body,(err,results)=>{
        if(err){
          console.log(err);
          return res.status(400).send({
           success:false,
           message: err.message,
           error:error
          }) 
        }
        console.log(results)
        return res.status(200).send(results + ' Record Inserted')
      })
       }
      catch(error){
        console.log(error)
        res.status(500).send({
          success:false,
          message:'internal srerver',
          error:error})
      }
    
    },
    patientPaymentDetails:(req,res)=>{
      try{
        patientPaymentDetails(req.body,(err,results)=>{
          if(err){
            console.log(err);
            return res.status(400).send({
             success:false,
             message: err.message,
             error:error
            }) 
          }
          console.log(results)
          return res.status(200).send(results +"Record Inserted")
        })
         }
        catch(error){
          console.log(error)
          res.status(500).send({
            success:false,
            message:'internal srerver',
            error:error})
        }      
    },
    getPatientProfile:(req,res)=>{
      try{
        getPatientProfile((err,results)=>{
          if(err){
            console.log(err);
            return res.status(400).send({
             success:false,
             message: err.message,
             error:error
        })
      }
      console.log(results)
      return res.status(200).send(results)
    })
  }
    catch(error){
      console.log(error)
      res.status(500).send({
        success:false,
        message:'internal srerver',
        error:error})   
       }
         },
         updatePatientProfile:(req,res)=>{
           try{
            updatePatientProfile(req.body,(err,results)=>{
              if(err){
                console.log(err);
                return res.status(400).send({
                 success:false,
                 message: err.message,
                 error:error
                }) 
              }
              console.log(results)
              return res.status(200).send(results +"Record Updated")
            })
             }
            catch(error){
              console.log(error)
              res.status(500).send({
                success:false,
                message:'internal srerver',
                error:error})
            }        
          },
          accountDeactivate:(req,res)=>{
            try{
              accountDeactivate(req.body.p_email,(err,results)=>{
                if(err){
                  console.log(err);
                  return res.status(400).send({
                   success:false,
                   message: err.message,
                   error:error
                  }) 
                }
                console.log(results)
                return res.status(200).send(results +"Record Deleted")
              })
               }
              catch(error){
                console.log(error)
                res.status(500).send({
                  success:false,
                  message:'internal srerver',
                  error:error})
              }   
                      
            } ,
            updatePatientPassword:(req,res)=>{
              try{
                updatePatientPassword(req.body,(err,results)=>{
                  if(err){
                    console.log(err);
                    return res.status(400).send({
                     success:false,
                     message: err.message,
                     error:error
                    }) 
                  }
                  console.log(results)
                  return res.status(200).send(results +"Record Updated")
                })
                 }
                catch(error){
                  console.log(error)
                  res.status(500).send({
                    success:false,
                    message:'internal srerver',
                    error:error})
                }    
            },
            updatePatientPin:(req,res)=>{
              try{
                updatePatientPin(req.body,(err,results)=>{
                  if(err){
                    console.log(err);
                    return res.status(400).send({
                     success:false,
                     message: err.message,
                     error:error
                    }) 
                  }
                  console.log(results)
                  return res.status(200).send(results +"Record Updated")
                })
                 }
                catch(error){
                  console.log(error)
                  res.status(500).send({
                    success:false,
                    message:'internal srerver',
                    error:error})
                }    
            },
            updatePatientStatus:(req,res)=>{
              try{
                updatePatientStatus(req.body,(err,results)=>{
                  if(err){
                    console.log(err);
                    return res.status(400).send({
                     success:false,
                     message: err.message,
                     error:error
                    }) 
                  }
                  console.log(results)
                  return res.status(200).send(results +"Record Updated")
                })
                 }
                catch(error){
                  console.log(error)
                  res.status(500).send({
                    success:false,
                    message:'internal srerver',
                    error:error})
                }    
            }


}

    
  
    
  
