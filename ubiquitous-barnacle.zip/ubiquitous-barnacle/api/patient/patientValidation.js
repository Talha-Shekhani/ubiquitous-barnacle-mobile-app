const { body } = require('express-validator')

module.exports = {
    loginValidation :  [
        // username must be an email
        body('p_email').isEmail(),
        // password must be at least 5 chars long
        body('p_password').isLength({ min: 5 }),
    ],  
    PatientDetialsInsertValidation : [
        body('p_email').isEmail().isLength({max : 254}).withMessage('Email must be in format.'),
        body('p_password').isLength({ min: 5 }).withMessage("password's length must be in 5."),
        body('p_title').isAlpha().isLength({ min : 2 , max : 3 }).withMessage('Title must be Alphabetic.'),
        body('p_first_name').matches(/^[A-Za-z\s]+$/).isLength({max : 19}).withMessage('Name must be alphabetic.'),
        body('p_last_name').matches(/^[A-Za-z\s]+$/).isLength({max : 19}).withMessage('Name must be alphabetic.'),
        body('p_country_id').isNumeric().isLength({max : 9}),
        body('p_state_id').isNumeric().isLength({max : 9}),
        body('p_city_id').isNumeric().isLength({max : 9}),
        body('p_phone_no').isNumeric().isLength({max : 29}),
        body('p_dob').toDate(),
        body('p_gender').isAlpha().isLength({ max : 1 }),
        body('p_pin_code').isNumeric().isLength({max : 4})
    ],
 }