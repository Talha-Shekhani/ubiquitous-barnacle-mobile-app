const knex = require("../../db/knex");
const bcrypt = require("bcryptjs");

module.exports = {

    login: ({p_email , p_password  }, callBack) => {
        knex
          .from("patient_profile")
          .select("p_email", "p_password" , "accout_locked")
          .where({ p_email })
          .then((rows) => {
            console.log(rows)
           
9
            if (rows.length === 0) return callBack(null, { auth: false });
            if (bcrypt.compareSync(p_password, rows[0].p_password)) {
              if (rows[0].accout_locked === 1) return callBack(null, { auth: false, msg: 'Account not Verified' });
              
              const payload = {
                p_email,
                type: "patient_profile",
              };
              return callBack(null, { auth: true, payload });
            }
            return callBack(null, { auth: false });
          })
          .catch((err) => {
            return callBack(err);
          });
      },
    patientsDetails: ({ p_email , p_password , p_title , p_first_name , p_last_name , p_country_id , p_state_id , p_city_id , p_phone_no , p_dob , p_gender , p_pin_code  }, callBack) => {
        knex("patient_profile")
        .insert([
            { p_email : p_email  ,
             p_password : p_password ,
             p_title : p_title ,
             p_first_name : p_first_name ,
             p_last_name : p_last_name ,
             p_country_id : p_country_id ,
             p_state_id : p_state_id ,
             p_city_id : p_city_id ,
             p_phone_no : p_phone_no ,
             p_dob : p_dob ,
             p_gender : p_gender  ,
             p_pin_code : p_pin_code ,
            }
          ])
          .then((rows) => { callBack(null,rows)})
      .catch((err) => { callBack(err) });
      ;
      },

      patientsAppointment: ({ doctor_slot_id , patient_id , doctor_id , patient_details_id , speciality }, callBack) => {
        knex("appointments")
        .insert([
            { doctor_slot_id : doctor_slot_id  ,
              patient_id : patient_id ,
              doctor_id : doctor_id ,
              patient_details_id : patient_details_id ,
              speciality : speciality ,
            }
          ])
          .then((rows) => { callBack(null,rows)})
      .catch((err) => { callBack(err) });
      ;

    },

    patientsAppointmentFor: ({ first_name , last_name , gender , dob , relation }, callBack) => {
      knex("patient_appointment_details")
      .insert([
          { first_name : first_name  ,
            last_name : last_name ,
            gender : gender ,
            dob : dob ,
            relation : relation ,
          }
        ])
        .then((rows) => { callBack(null,rows)})
    .catch((err) => { callBack(err) });
    ;

  },
  getCities:(state_id,callBack)=>{
    const results ={};
    knex
    .from("cities")
    .select("id","city_name")
.where({state_id})
    .then((rows)=>{
      results["results"]=rows
      callBack(null,results);
    })
.catch((err)=>callBack(err));
  },

  getState:(country_id,callBack)=>{
    const results={};
    knex
    .from("states")
    .select("id","state_name")
    .where({country_id})
    .then((rows)=>{
      results["results"]=rows
      callBack(null,results)
    })
    .catch((err)=>callBack(err));
  },

  getDisease:(callBack)=>{
    const results ={};
    knex
    .from("Disease")
    .select("id","disease_name")
    .then((rows)=>{
      results["results"]=rows
      callBack(null,results)
    })
    .catch((err)=>callBack(err));
  },
  
  getSlots:(callBack)=>{
    const results ={};
    knex
    .from("slots")
    .select("id","start_time","end_time")
    .then((rows)=>{
      results["results"]= rows
      callBack(null,results)
    })
    .catch((err)=>callBack(err))
  },

  getSubSpeciality:(callBack)=>{
    const results={};
    knex
    .from("doctor_speciality")
    .select("sub_speciality_id")
    .then((rows)=>{
      results["results"]=rows
      callBack(null,results)
    })
    .catch((err)=>callBack(err));
  },

  getDoctorId:(sub_speciality_id,callBack)=>{
    const results ={};
    
    knex
    .from("doctor_speciality")
    .select("doctor_id","d_first_name")
   
    .where({sub_speciality_id:sub_speciality_id})
    .join('doctor_profile', 'doctor_speciality.doctor_id', '=', 'doctor_profile.id')  
    .then((rows)=>{
      results["results"]=rows
      
      callBack(null,results)
        })
        .catch((err)=>callBack(err));
  },
  getDoctor:(callBack)=>{
    const results = {};
    knex
    .from("doctor_profile")
    .select("id","d_first_name")
    .then((rows)=>{
      results["results"]=rows
      callBack(null,results)
    })
    .catch((err)=>{
      callBack(err)
    })
  },
  getDoctorDetails:(id,callBack)=>{
    const results ={};
    knex
    .from("doctor_profile")
    .select("d_phone_no","qualificaiton_id","qual_name","primary_speciality_id","speciality_name","sub_speciality_id","sub_speciality_name","available")
    
    
    .join('doctor_qualification', 'doctor_profile.id', '=', 'doctor_qualification.doctor_id')  
    .join('qualification', 'doctor_qualification.qualificaiton_id', '=', 'qualification.id')
    .join('doctor_speciality', 'doctor_profile.id', '=', 'doctor_speciality.doctor_id')
    .join('doctor_speciality_name','doctor_speciality.primary_speciality_id','=','doctor_speciality_name.id')
    .join('doctor_sub_speciality_name','doctor_speciality.sub_speciality_id','=','doctor_sub_speciality_name.id')
    .join('doctor_available_slots','doctor_profile.id','=','doctor_available_slots.doctor_id ')
     .where({"doctor_profile.id":id,"doctor_available_slots.available":0})

    .then((rows)=>{
      results["results"]=rows
      callBack(null,results);
      
    })
    .catch((err)=>callBack(err))
  },

  getAppointmentDetails:(patient_id,callBack)=>{
    const results={};
    knex
    
    .raw("INSERT INTO `patient_appointment_details`(`patient_id`,`first_name`,`last_name`,`gender`,`dob`) SELECT id,p_first_name,p_last_name,p_gender,p_dob FROM patient_profile WHERE patient_profile.id = "+patient_id)
      .then((rows) => { callBack(null,rows)})
    .catch((err) => { callBack(err) });
  },
  appointmentDetailsOfOthers:({patient_id,first_name,last_name,gender,dob,relation},callBack)=>{
   
    knex("patient_appointment_details")
    .insert([{
      patient_id:patient_id,
      first_name:first_name,
      last_name:last_name,
      gender:gender,
      dob:dob,
      relation:relation
    }
  ])
    
       .then((rows) => { callBack(null,rows)})
    .catch((err) => { callBack(err) });
  },
  patientPaymentDetails:({card_number,total_payment,currency_type},callBack)=>{
    knex("patient_payment_details")
    .insert([{
      card_number:card_number,
      total_payment:total_payment,
      currency_type:currency_type
    }])
    .then((rows) => { callBack(null,rows)})
    .catch((err) => { callBack(err) });
  },
  getPatientProfile:(callBack)=>{
      const results = {};
      knex
      .from("patient_profile")
      .select("id","p_email","p_password","p_title","p_first_name","p_last_name","p_phone_no","p_dob","p_gender","p_pin_code")
      .then((rows)=>{
        results["results"]=rows
        callBack(null,results)
      })
      .catch((err)=>{
        callBack(err)
      });
  },
  updatePatientProfile:({p_email,p_title,p_first_name,p_last_name,p_phone_no,p_dob,p_gender},callBack)=>{
    knex("patient_profile")
    .where({"p_email": p_email})
    .update({      
   
      p_title:p_title,
      p_first_name:p_first_name,
      p_last_name:p_last_name,
      p_phone_no:p_phone_no,
      p_dob:p_dob,
      p_gender:p_gender,
    
        })
        .then((rows) => { callBack(null,rows)})
        .catch((err) => { callBack(err) });
  },
  accountDeactivate:(p_email,callBack)=>{
    knex("patient_profile")
    .where({"p_email":p_email})
    .del()
    .then((rows) => { callBack(null,rows)})
    .catch((err) => { callBack(err) });
  },
  updatePatientPassword:({p_email,p_password},callBack)=>{
    knex("patient_profile")
    .where({"p_email":p_email})
    .update({p_password:p_password})
    .then((rows) => { callBack(null,rows)})
        .catch((err) => { callBack(err) });
  },
  
  updatePatientPin:({p_email,p_pin_code},callBack)=>{
    knex("patient_profile")
    .where({"p_email":p_email})
    .update({p_pin_code:p_pin_code})
    .then((rows) => { callBack(null,rows)})
        .catch((err) => { callBack(err) });
  },

  updatePatientStatus:({p_email,account_status},callBack)=>{
    knex("patient_profile")
    .where({"p_email":p_email})
    .update({account_status:account_status})
    .then((rows) => { callBack(null,rows)})
    .catch((err) => { callBack(err) });
  }
};
