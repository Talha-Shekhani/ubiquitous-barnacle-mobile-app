const { 
   forgotPassword , resetPassword , resetPasswordPost
} = require("./generalController"); 

const router = require ("express").Router();



router.post('/forgot/:type', forgotPassword);
router.get('/resetPassword' , resetPassword)
router.post('/resetPasswordPost' , resetPasswordPost)

module.exports = router;