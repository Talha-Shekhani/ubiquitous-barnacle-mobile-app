const knex = require("../../db/knex");
const crypto = require("crypto")
const transport = require("../../config/mail");
const { as } = require("../../db/knex");
const bcrypt = require("bcryptjs");

module.exports = {

    forgotPassword : async ({email, reset_type}, callBack) => {
       const isEmail = await knex
        .from("doctor_profile")
        .select("d_email" , "d_title" , "d_first_name" , "d_last_name")
        .where({"d_email" : email})
        if (isEmail == null) {
              return callBack(null, {status: "ok"}) ;
            }


        await knex
         .from("resettokens")
         .where({ "email" : email })
         .update({ used : 1 })
       
        var fpSalt = crypto.randomBytes(64).toString('base64');
        
        var expireDate = new Date();
        expireDate.setDate(expireDate.getDate() + 1/24);
       
        await knex
        .from("resettokens")
        .insert([{ email,
                    expiration : expireDate , 
                    token : fpSalt  , 
                    used : 0,
                    reset_type
                }])
    
        const message = {
            from: process.env.SENDER_ADDRESS,
            to: email,
            subject: "Forgot Password",
            text : `To reset your password, please click the link below.
            https://localhost:5000/api/general/resetPassword?token=${encodeURIComponent(fpSalt)}+&email=${email}`
        };
        transport.sendMail(message, function (err, info) {
            if(err) { console.log(err)}
            else { console.log(info); }
         });
        
         callBack(null,{status: 'ok'})
      },

      
    resetPassword : async ({email,token}, callBack) => {
        const day = new Date().getDate();
        const month = new Date().getMonth() + 1;
        const year = new Date().getFullYear();
        const completeDate = `${year}-${month}-${day}`
        const usedValue = 0 ;

        try{
        await knex("resettokens")
        .whereRaw(`expiration < '${completeDate}' `)
        .del()
            console.log(token);
        const record = await
        knex("resettokens")
        .select("email","token")
        .whereRaw(`email = '${email}' AND DATE(expiration) = '${completeDate}' AND token = '${token}' AND used  = ${usedValue} `)
        
        if(record == null){
            callBack(null,{ message: 'Token has expired. Please try password reset again.',
            showForm: false})
        }

        callBack(null,{
            showForm: true,
            record: { token, email}
        })

     } catch(error){
         callBack(error);
     }
    },

    resetPasswordPost : async ({email,password1, token}, callBack) => {
        
    const day = new Date().getDate();
    const month = new Date().getMonth() + 1;
    const year = new Date().getFullYear();
    const completeDate = `${year}-${month}-${day}`
    const usedValue = 0 ;
    const usedValues = 1 ;
        
    console.log(completeDate,token ,email)
    knex("resettokens")
    .select("email","token")
    // .where({
    //     'email': email,
    //     'expiration' : completeDate,
    //     'token': token,
    //     'used': 0
    // })
    .whereRaw(`email = '${email}' AND expiration = '${completeDate}' AND token = '${token}' AND used  = 0 `)
    .then(async (rows) => {
        console.log(rows);
        if(rows.length < 1){
            
            return callBack(null,{ message: 'Token not found. Please try the reset password process again..', status : false

        })}
        
        await knex("resettokens").where({ email: email }).update({  used : 1})
        const newPassword = bcrypt.hashSync(password1, 10 );
        console.log(newPassword)
        knex("doctor_profile")
        .where({ d_email: email })
        .update({  d_password : newPassword})
        .then(rows => {
            callBack(null ,{status: true , message: 'Password reset. Please login with your new password.'});
        })
        .catch(err => {
            return callBack(err)
        })
    })  
    .catch(err => {
        return callBack(err)
    })
    

    
   
    
    }
};