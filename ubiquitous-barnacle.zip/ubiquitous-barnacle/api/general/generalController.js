const { forgotPassword , resetPassword , resetPasswordPost
} = require("./generalServices");
const JWT = require("jsonwebtoken");


module.exports = {
    forgotPassword : (req , res) => {
      const reset_type = req.params.type;
      const email = req.body.email
        forgotPassword({email, reset_type} , (err , results) => {
           if(err) {
             console.log(err);
             return res.status(400).send(err);
           };
           console.log(results);
       
           
           return res.status(200).send(results);
       
         })
       },

       resetPassword : (req , res) => {
        const token = req.query.token;
        const email = req.query.email
        resetPassword({email, token} , (err , results) => {
             if(err) {
               console.log(err);
               return res.render('reset-password',{
                 showForm: false,
                 message: 'Something Went Wrong!'
               })
             };
             console.log(results);
         
             
             return res.render('reset-password',results)
         
           })
         },
         resetPasswordPost : (req , res) => {
          const { password1, password2 , token , email } = req.body;
          console.log(password1 , password2);
          if (password1 !== password2) return res.status(200).send({success: false})
          
          resetPasswordPost({email, token,password1} , (err , results) => {
               if(err) {
                 console.log(err);
                 return res.status(400).send({success : false , message : "something went wrong !"})
               };
               console.log(results);
           
              })
           },
};