const { 
    login , getPatients , getDoctors , logout , blockPatientProfile , patientsAppointmentDetails , blockDoctorProfile,
    blockDoctorCharges
    } = require("./adminController"); 
const { isAuthenticated } = require('../../middleware/isAuthenticated');
const router = require ("express").Router();
const {loginValidation  } = require('./adminValidation');
const isValidated = require('../../middleware/isValidated');

router.post("/login", loginValidation , isValidated ,login);
router.get("/get/patients",isAuthenticated,getPatients);
router.get("/get/doctors",isAuthenticated,getDoctors);
router.get("/logout",isAuthenticated,logout);
router.put("/block/patient",isAuthenticated,blockPatientProfile);
router.get("/get/patient/appointment",patientsAppointmentDetails);
router.put("/block/doctor",isAuthenticated,blockDoctorProfile);
router.put("/block/doctor/charges",isAuthenticated,blockDoctorCharges);

module.exports = router;
