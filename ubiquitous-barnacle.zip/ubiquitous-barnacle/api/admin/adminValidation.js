const { body } = require('express-validator')

module.exports = {
    loginValidation :  [
        body('username').matches(/^[A-Za-z\s]+$/).isLength({max : 254 }),
        body('password').isLength({ min: 5 , max : 254 })
    ]
}