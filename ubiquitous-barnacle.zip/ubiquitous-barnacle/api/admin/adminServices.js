const knex = require("../../db/knex");
const bcrypt = require("bcryptjs");

module.exports = {
  login: ({ username, password }, callBack) => {
    knex
      .from("admin")
      .select("username", "password")
      .where({ username })
      .then((rows) => {
        if (rows.length === 0) return callBack(null, { auth: false });
        if (bcrypt.compareSync(password, rows[0].password)) {
          const payload = {
            username,
            type: "admin",
          };
          return callBack(null, { auth: true, payload });
        }
        return callBack(null, { auth: false });
      })
      .catch((err) => {
        return callBack(err);
      });
  },
  getPatients: ({ searchTerm, limit, startIndex, endIndex }, callBack) => {
    const results = {};
    knex /* Query to get the total count */
      .from("patient_profile")
      .count("id as totalCount")
      .whereRaw(
        `p_first_name LIKE '%${searchTerm}%' OR p_last_name LIKE '%${searchTerm}%'
       OR p_email LIKE '%${searchTerm}%'`
      )
      .then((rows) => {
        const numberOfRows = rows[0].totalCount;
        results["totalPages"] = Math.ceil(numberOfRows / limit);
        console.log("serach count", numberOfRows);
        if (endIndex < numberOfRows) {
          results.next = {
            page: page + 1,
            limit: limit,
          };
        }

        if (startIndex > 0) {
          results.previous = {
            page: page - 1,
            limit: limit,
          };
        }

        knex /* Search Query */
          .from("patient_profile")
          .select(
            "p_email",
            "p_first_name",
            "p_last_name",
            "p_title",
            "accout_locked",
            "p_phone_no",
            "p_dob",
            "id"
          )
          .whereRaw(
            `p_first_name LIKE '%${searchTerm}%' OR p_last_name LIKE '%${searchTerm}%'
         OR p_email LIKE '%${searchTerm}%'`
          )
          .orderBy("created_at")
          .limit(limit)
          .offset(startIndex)
          .then((rows) => {
            results["results"] = rows;
            callBack(null, results);
          })
          .catch((err) => callBack(err));
      })
      .catch((err) => callBack(err));
  },

  getDoctors: ({ searchTerm, limit, startIndex, endIndex }, callBack) => {
    const results = {};
    knex /* Query to get the total count */
      .from("doctor_profile")
      .count("id as totalCount")
      .whereRaw(
        `d_first_name LIKE '%${searchTerm}%' OR d_last_name LIKE '%${searchTerm}%'
       OR d_email LIKE '%${searchTerm}%'`
      )
      .then((rows) => {
        const numberOfRows = rows[0].totalCount;
        results["totalPages"] = Math.ceil(numberOfRows / limit);
        console.log("serach count", numberOfRows);
        if (endIndex < numberOfRows) {
          results.next = {
            page: page + 1,
            limit: limit,
          };
        }

        if (startIndex > 0) {
          results.previous = {
            page: page - 1,
            limit: limit,
          };
        }

        knex /* Search Query */
          .from("doctor_profile")
          .select(
            "d_email",
            "d_first_name",
            "d_last_name",
            "d_title",
            "accout_locked",
            "d_charges_flag",
            "d_charges",
            "d_dob",
            "d_phone_no",
            "id"

          )
          .whereRaw(
            `d_first_name LIKE '%${searchTerm}%' OR d_last_name LIKE '%${searchTerm}%'
         OR d_email LIKE '%${searchTerm}%'`
          )
          .orderBy("created_at")
          .limit(limit)
          .offset(startIndex)
          .then((rows) => {
            results["results"] = rows;
            callBack(null, results);
          })
          .catch((err) => callBack(err));
      })
      .catch((err) => callBack(err));
  },

  blockPatientProfile: ({ id, value }, callBack) => {
    knex("patient_profile")
      .where({ id: id })
      .update({ accout_locked: value })
      .then((rows) => { callBack(null,rows)})
      .catch((err) => { callBack(err) });
      ;

  },

  blockDoctorProfile: ({ id, value }, callBack) => {
    knex("doctor_profile")
      .where({ id: id })
      .update({ accout_locked: value })
      .then((rows) => { callBack(null,rows)})
      .catch((err) => { callBack(err) });
      ;

  },

  blockDoctorCharges: ({ id, value , charges }, callBack) => {
    knex("doctor_profile")
      .where({ id: id })
      .update({d_charges_flag : value , d_charges: charges })
      .then((rows) => { callBack(null,rows)})
      .catch((err) => { callBack(err) });
      ;

  },
  patientsAppointmentDetails: ({ id , searchTerm, limit, startIndex, endIndex }, callBack) => {
    const results = {};
    knex /* Query to get the total count */
      .from("appointments")
      .count("id as totalCount")
      .whereRaw(
        `patient_id LIKE '%${searchTerm}%' OR doctor_id LIKE '%${searchTerm}%'
       OR doctor_slot_id LIKE '%${searchTerm}%'`
      )
      .then((rows) => {
        const numberOfRows = rows[0].totalCount;
        results["totalPages"] = Math.ceil(numberOfRows / limit);
        console.log("serach count", numberOfRows);
        if (endIndex < numberOfRows) {
          results.next = {
            page: page + 1,
            limit: limit,
          };
        }

        if (startIndex > 0) {
          results.previous = {
            page: page - 1,
            limit: limit,
          };
        }

        knex /* Search Query */
          .from("appointments")
          .where('id', id )
          .whereRaw(
            `patient_id LIKE '%${searchTerm}%' OR doctor_id LIKE '%${searchTerm}%'
         OR doctor_slot_id LIKE '%${searchTerm}%'`
          )
          .orderBy("patient_id")
          .limit(limit)
          .offset(startIndex)
          .then((rows) => {
            results["results"] = rows;
            callBack(null, results);
          })
          .catch((err) => callBack(err));
      })
      .catch((err) => callBack(err));
  }
};
