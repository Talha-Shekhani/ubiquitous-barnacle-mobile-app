const { login , getPatients , getDoctors , blockPatientProfile , patientsAppointmentDetails , blockDoctorProfile 
, blockDoctorCharges
} = require("./adminServices");
const JWT = require("jsonwebtoken");

module.exports = {
  login: (req, res) => {
    const username = req.body.username;
    const password = req.body.password;

    login({ username, password }, (err, results) => {
      if (err) {
        console.log(err);
        return res.json({
          err,
        });
      }
      if (!results.auth) {
        return res.json({
          success: 0,
          message: "Username or Password Incorrect!",
        });
      }
      const token = JWT.sign(results.payload, "SECRET");
      res.cookie("access_token", token, {
        maxAge: 1000 * 60 * 60 * 24 * 365, // Unlimited Time
        httpOnly: true,
      });
      return res.json({
        ...results.payload,
        success: true,
      });
    });
  },
  /* Logout Route */
  logout : (req,res) => {

    res.cookie('access_token','',{
      maxAge: 1000, 
      httpOnly:true,
    })
    res.status(200).send('User logged out successfully.')
  },

	

  getPatients: (req, res) => {
  	const page = parseInt(req.query.page)
	  const limit = parseInt(req.query.limit)
	  const searchTerm = req.query.search;
	  const startIndex = (page - 1) * limit;
	  const endIndex = page * limit;

	  getPatients({searchTerm, limit, searchTerm}, (err, results) => {
	  	if(err) {
        console.log(err);
        return res.status(400).send(err);
      };
      console.log(results);

   	  return res.status(200).send(results);
	  })
},
getDoctors: (req, res) => {
  const page = parseInt(req.query.page)
  const limit = parseInt(req.query.limit)
  const searchTerm = req.query.search;
  const startIndex = (page - 1) * limit;
  const endIndex = page * limit;

  getDoctors({searchTerm, limit, searchTerm}, (err, results) => {
    if(err) {
      console.log(err);
      return res.status(400).send(err);
    };
    console.log(results);

     return res.status(200).send(results);
  })
},
blockPatientProfile : (req , res) => {
  const { id, value } = req.body
  blockPatientProfile({id, value}, (err , results) => {
    if(err) {
      console.log(err);
      return res.status(400).send(err);
    };
    console.log(results);

    return res.status(200).send(results + ' Record(s) updated');

  })
},
  blockDoctorProfile : (req , res) => {
  const { id, value } = req.body
  blockDoctorProfile({id, value}, (err , results) => {
    if(err) {
      console.log(err);
      return res.status(400).send(err);
    };
    console.log(results);

    return res.status(200).send(results + ' Record(s) updated');

  })
},

blockDoctorCharges : (req , res) => {
  const { id, value , charges } = req.body
  blockDoctorCharges({id, value , charges }, (err , results) => {
    if(err) {
      console.log(err);
      return res.status(400).send(err);
    };
    console.log(results);

    return res.status(200).send(results + ' Record(s) updated');

  })
},

patientsAppointmentDetails: (req, res) => {
  const page = parseInt(req.query.page)
  const id = parseInt(req.query.id)
  const limit = parseInt(req.query.limit)
  const searchTerm = req.query.search;
  const startIndex = (page - 1) * limit;
  const endIndex = page * limit;

  patientsAppointmentDetails({ id ,searchTerm, limit, searchTerm}, (err, results) => {
    if(err) {
      console.log(err);
      return res.status(400).send(err);
    };
    console.log(results);

     return res.status(200).send(results);
  })
}

};
