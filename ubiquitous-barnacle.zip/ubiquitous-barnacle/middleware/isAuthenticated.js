const JWT = require('jsonwebtoken');
const SECRET = 'SECRET'; 
const knex = require('../db/knex.js');

const isAuthenticated = (req, res, next) => {
	const token = req.cookies.access_token;
	if(token){
		JWT.verify(token,SECRET,(err,decoded) => {
			if(err){
				res.status(401).send('Unauthorized');
			} else {
				const condition = decoded.type === 'admin' ? {username : decoded.username} : { email : decoded.email}
				knex
				.from(decoded.type)
				.count('* as totalCount')
				.where(condition)
				.then(rows => {
                    console.log('success');
					if(rows[0].totalCount === 0) return res.status(401).send('Unauthorized.');

					next();
				})
				.catch(err => {
					console.log(err);
					res.status(401).send('User not Authorized!');
				})
			}
		})
	} else {
		res.status(401).send('Unauthorized.');
	}
};

module.exports = {
	isAuthenticated
}
